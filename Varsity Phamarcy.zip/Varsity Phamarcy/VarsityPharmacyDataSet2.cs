﻿namespace Varsity_Phamarcy
{


    partial class VarsityPharmacyDataSet2
    {
        partial class StaffDataTable
        {
        }
    }
}
