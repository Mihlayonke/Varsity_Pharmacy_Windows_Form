﻿
namespace Varsity_Phamarcy
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customer));
            this.Surname = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.customerID = new System.Windows.Forms.TextBox();
            this.Phone = new System.Windows.Forms.MaskedTextBox();
            this.AidName = new System.Windows.Forms.ComboBox();
            this.Number = new System.Windows.Forms.MaskedTextBox();
            this.Identity = new System.Windows.Forms.MaskedTextBox();
            this.Gend = new System.Windows.Forms.TextBox();
            this.AidNumber = new System.Windows.Forms.TextBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.custIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custFNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custLNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custEmailAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custIDNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custAgeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custPhoneNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custGenderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MedicalAidName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicalAidNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custFName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custLName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custEmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custIDNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custAge = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custPhoneNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custGender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicalAidNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.varsityPharmacyDataSet2 = new Varsity_Phamarcy.VarsityPharmacyDataSet2();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Search = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Name = new System.Windows.Forms.TextBox();
            this.customersTableAdapter = new Varsity_Phamarcy.VarsityPharmacyDataSet2TableAdapters.CustomersTableAdapter();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custFNameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custLNameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custEmailAddressDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custIDNumberDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custAgeDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custPhoneNumberDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custGenderDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicalAidNumberDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.varsityPharmacyDataSet2)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Surname
            // 
            this.Surname.Location = new System.Drawing.Point(125, 133);
            this.Surname.Name = "Surname";
            this.Surname.Size = new System.Drawing.Size(202, 20);
            this.Surname.TabIndex = 2;
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(125, 187);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(202, 20);
            this.Email.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(10, 521);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 65);
            this.button1.TabIndex = 10;
            this.button1.Text = "ADD";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(179, 521);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(148, 66);
            this.button3.TabIndex = 12;
            this.button3.Text = "UPDATE";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Location = new System.Drawing.Point(1206, 516);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(146, 69);
            this.button4.TabIndex = 13;
            this.button4.Text = "HOME";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.TabIndex = 16;
            this.label2.Text = "CustFName";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "CustLName";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(10, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 16);
            this.label4.TabIndex = 18;
            this.label4.Text = "CustEmail";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 16);
            this.label5.TabIndex = 19;
            this.label5.Text = "CustIdentity";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(10, 306);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 16);
            this.label7.TabIndex = 21;
            this.label7.Text = "CustPhone";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 364);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 16);
            this.label8.TabIndex = 22;
            this.label8.Text = "MedAidName";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 419);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 16);
            this.label9.TabIndex = 23;
            this.label9.Text = "MedicalAid";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.label11);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1581, 48);
            this.panel1.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Location = new System.Drawing.Point(526, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(413, 39);
            this.label11.TabIndex = 0;
            this.label11.Text = "MANAGE CUSTOMERS";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel2.Location = new System.Drawing.Point(3, 591);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1567, 21);
            this.panel2.TabIndex = 26;
            // 
            // customerID
            // 
            this.customerID.Location = new System.Drawing.Point(125, 57);
            this.customerID.Name = "customerID";
            this.customerID.Size = new System.Drawing.Size(48, 20);
            this.customerID.TabIndex = 27;
            this.customerID.Visible = false;
            // 
            // Phone
            // 
            this.Phone.Location = new System.Drawing.Point(125, 302);
            this.Phone.Mask = "+27000000000";
            this.Phone.Name = "Phone";
            this.Phone.Size = new System.Drawing.Size(202, 20);
            this.Phone.TabIndex = 28;
            // 
            // AidName
            // 
            this.AidName.FormattingEnabled = true;
            this.AidName.Items.AddRange(new object[] {
            "Discovery Health",
            "Government Employees Medical Scheme",
            "Bonitas",
            "Polmed",
            "Momentum Health",
            "Bankmed",
            "Bestmed Medical Scheme",
            "Medihelp",
            "Medshield",
            "LA-Health Medical Scheme",
            "FedHealth Scheme",
            "Platinum Health",
            "SAMWUMed",
            "Keyhealth"});
            this.AidName.Location = new System.Drawing.Point(125, 359);
            this.AidName.Name = "AidName";
            this.AidName.Size = new System.Drawing.Size(202, 21);
            this.AidName.TabIndex = 29;
            // 
            // Number
            // 
            this.Number.Location = new System.Drawing.Point(210, 57);
            this.Number.Mask = "00";
            this.Number.Name = "Number";
            this.Number.Size = new System.Drawing.Size(105, 20);
            this.Number.TabIndex = 30;
            this.Number.ValidatingType = typeof(int);
            this.Number.Visible = false;
            // 
            // Identity
            // 
            this.Identity.Location = new System.Drawing.Point(125, 248);
            this.Identity.Mask = "0000000000000";
            this.Identity.Name = "Identity";
            this.Identity.Size = new System.Drawing.Size(202, 20);
            this.Identity.TabIndex = 31;
            this.Identity.ValidatingType = typeof(int);
            // 
            // Gend
            // 
            this.Gend.Location = new System.Drawing.Point(15, 57);
            this.Gend.Name = "Gend";
            this.Gend.Size = new System.Drawing.Size(54, 20);
            this.Gend.TabIndex = 33;
            this.Gend.Visible = false;
            // 
            // AidNumber
            // 
            this.AidNumber.Location = new System.Drawing.Point(125, 415);
            this.AidNumber.Name = "AidNumber";
            this.AidNumber.Size = new System.Drawing.Size(202, 20);
            this.AidNumber.TabIndex = 34;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(16, 19);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(82, 20);
            this.radioButton1.TabIndex = 35;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Activate";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(200, 19);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(101, 20);
            this.radioButton2.TabIndex = 36;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Deactivate";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(349, 57);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(59, 20);
            this.textBox10.TabIndex = 37;
            this.textBox10.Visible = false;
            // 
            // custIDDataGridViewTextBoxColumn
            // 
            this.custIDDataGridViewTextBoxColumn.DataPropertyName = "custID";
            this.custIDDataGridViewTextBoxColumn.HeaderText = "custID";
            this.custIDDataGridViewTextBoxColumn.Name = "custIDDataGridViewTextBoxColumn";
            this.custIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // custFNameDataGridViewTextBoxColumn
            // 
            this.custFNameDataGridViewTextBoxColumn.DataPropertyName = "custFName";
            this.custFNameDataGridViewTextBoxColumn.HeaderText = "custFName";
            this.custFNameDataGridViewTextBoxColumn.Name = "custFNameDataGridViewTextBoxColumn";
            // 
            // custLNameDataGridViewTextBoxColumn
            // 
            this.custLNameDataGridViewTextBoxColumn.DataPropertyName = "custLName";
            this.custLNameDataGridViewTextBoxColumn.HeaderText = "custLName";
            this.custLNameDataGridViewTextBoxColumn.Name = "custLNameDataGridViewTextBoxColumn";
            // 
            // custEmailAddressDataGridViewTextBoxColumn
            // 
            this.custEmailAddressDataGridViewTextBoxColumn.DataPropertyName = "custEmailAddress";
            this.custEmailAddressDataGridViewTextBoxColumn.HeaderText = "custEmailAddress";
            this.custEmailAddressDataGridViewTextBoxColumn.Name = "custEmailAddressDataGridViewTextBoxColumn";
            // 
            // custIDNumberDataGridViewTextBoxColumn
            // 
            this.custIDNumberDataGridViewTextBoxColumn.DataPropertyName = "custIDNumber";
            this.custIDNumberDataGridViewTextBoxColumn.HeaderText = "custIDNumber";
            this.custIDNumberDataGridViewTextBoxColumn.Name = "custIDNumberDataGridViewTextBoxColumn";
            // 
            // custAgeDataGridViewTextBoxColumn
            // 
            this.custAgeDataGridViewTextBoxColumn.DataPropertyName = "custAge";
            this.custAgeDataGridViewTextBoxColumn.HeaderText = "custAge";
            this.custAgeDataGridViewTextBoxColumn.Name = "custAgeDataGridViewTextBoxColumn";
            // 
            // custPhoneNumberDataGridViewTextBoxColumn
            // 
            this.custPhoneNumberDataGridViewTextBoxColumn.DataPropertyName = "custPhoneNumber";
            this.custPhoneNumberDataGridViewTextBoxColumn.HeaderText = "custPhoneNumber";
            this.custPhoneNumberDataGridViewTextBoxColumn.Name = "custPhoneNumberDataGridViewTextBoxColumn";
            // 
            // custGenderDataGridViewTextBoxColumn
            // 
            this.custGenderDataGridViewTextBoxColumn.DataPropertyName = "custGender";
            this.custGenderDataGridViewTextBoxColumn.HeaderText = "custGender";
            this.custGenderDataGridViewTextBoxColumn.Name = "custGenderDataGridViewTextBoxColumn";
            // 
            // MedicalAidName
            // 
            this.MedicalAidName.DataPropertyName = "MedicalAidName";
            this.MedicalAidName.HeaderText = "MedicalAidName";
            this.MedicalAidName.Name = "MedicalAidName";
            // 
            // medicalAidNumberDataGridViewTextBoxColumn
            // 
            this.medicalAidNumberDataGridViewTextBoxColumn.DataPropertyName = "medicalAidNumber";
            this.medicalAidNumberDataGridViewTextBoxColumn.HeaderText = "medicalAidNumber";
            this.medicalAidNumberDataGridViewTextBoxColumn.Name = "medicalAidNumberDataGridViewTextBoxColumn";
            // 
            // custID
            // 
            this.custID.DataPropertyName = "custID";
            this.custID.HeaderText = "custID";
            this.custID.Name = "custID";
            // 
            // custFName
            // 
            this.custFName.DataPropertyName = "custFName";
            this.custFName.HeaderText = "custName";
            this.custFName.Name = "custFName";
            // 
            // custLName
            // 
            this.custLName.DataPropertyName = "custLName";
            this.custLName.HeaderText = "custSurname";
            this.custLName.Name = "custLName";
            // 
            // custEmailAddress
            // 
            this.custEmailAddress.DataPropertyName = "custEmailAddress";
            this.custEmailAddress.HeaderText = "custEmailAddress";
            this.custEmailAddress.Name = "custEmailAddress";
            // 
            // custIDNumber
            // 
            this.custIDNumber.DataPropertyName = "custIDNumber";
            this.custIDNumber.HeaderText = "custIDNumber";
            this.custIDNumber.Name = "custIDNumber";
            // 
            // custAge
            // 
            this.custAge.DataPropertyName = "custAge";
            this.custAge.HeaderText = "custAge";
            this.custAge.Name = "custAge";
            // 
            // custPhoneNumber
            // 
            this.custPhoneNumber.DataPropertyName = "custPhoneNumber";
            this.custPhoneNumber.HeaderText = "custPhoneNumber";
            this.custPhoneNumber.Name = "custPhoneNumber";
            // 
            // custGender
            // 
            this.custGender.DataPropertyName = "custGender";
            this.custGender.HeaderText = "custGender";
            this.custGender.Name = "custGender";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "MedicalAidName";
            this.dataGridViewTextBoxColumn1.HeaderText = "MedicalAidName";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // medicalAidNumber
            // 
            this.medicalAidNumber.DataPropertyName = "medicalAidNumber";
            this.medicalAidNumber.HeaderText = "medicalAidNumber";
            this.medicalAidNumber.Name = "medicalAidNumber";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "custID";
            this.dataGridViewTextBoxColumn2.HeaderText = "custID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "custFName";
            this.dataGridViewTextBoxColumn3.HeaderText = "custFName";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "custLName";
            this.dataGridViewTextBoxColumn4.HeaderText = "custLName";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "custEmailAddress";
            this.dataGridViewTextBoxColumn5.HeaderText = "custEmailAddress";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "custIDNumber";
            this.dataGridViewTextBoxColumn6.HeaderText = "custIDNumber";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "custAge";
            this.dataGridViewTextBoxColumn7.HeaderText = "custAge";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "custPhoneNumber";
            this.dataGridViewTextBoxColumn8.HeaderText = "custPhoneNumber";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "custGender";
            this.dataGridViewTextBoxColumn9.HeaderText = "custGender";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "MedicalAidName";
            this.dataGridViewTextBoxColumn10.HeaderText = "MedicalAidName";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "medicalAidNumber";
            this.dataGridViewTextBoxColumn11.HeaderText = "medicalAidNumber";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12,
            this.custFNameDataGridViewTextBoxColumn2,
            this.custLNameDataGridViewTextBoxColumn2,
            this.custEmailAddressDataGridViewTextBoxColumn2,
            this.custIDNumberDataGridViewTextBoxColumn2,
            this.custAgeDataGridViewTextBoxColumn2,
            this.custPhoneNumberDataGridViewTextBoxColumn2,
            this.custGenderDataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn13,
            this.medicalAidNumberDataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn14});
            this.dataGridView1.DataSource = this.bindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(349, 84);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1003, 378);
            this.dataGridView1.TabIndex = 38;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_2);
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataMember = "Customers";
            this.bindingSource1.DataSource = this.varsityPharmacyDataSet2;
            // 
            // varsityPharmacyDataSet2
            // 
            this.varsityPharmacyDataSet2.DataSetName = "VarsityPharmacyDataSet2";
            this.varsityPharmacyDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.Search);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(576, 516);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(346, 60);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Search Customer";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Name";
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(81, 23);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(249, 22);
            this.Search.TabIndex = 3;
            this.Search.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton2);
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(9, 458);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(317, 53);
            this.groupBox3.TabIndex = 41;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Status";
            // 
            // Name
            // 
            this.Name.Location = new System.Drawing.Point(125, 84);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(201, 20);
            this.Name.TabIndex = 42;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "custID";
            this.dataGridViewTextBoxColumn12.HeaderText = "custID";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // custFNameDataGridViewTextBoxColumn2
            // 
            this.custFNameDataGridViewTextBoxColumn2.DataPropertyName = "custFName";
            this.custFNameDataGridViewTextBoxColumn2.HeaderText = "custFName";
            this.custFNameDataGridViewTextBoxColumn2.Name = "custFNameDataGridViewTextBoxColumn2";
            // 
            // custLNameDataGridViewTextBoxColumn2
            // 
            this.custLNameDataGridViewTextBoxColumn2.DataPropertyName = "custLName";
            this.custLNameDataGridViewTextBoxColumn2.HeaderText = "custLName";
            this.custLNameDataGridViewTextBoxColumn2.Name = "custLNameDataGridViewTextBoxColumn2";
            // 
            // custEmailAddressDataGridViewTextBoxColumn2
            // 
            this.custEmailAddressDataGridViewTextBoxColumn2.DataPropertyName = "custEmailAddress";
            this.custEmailAddressDataGridViewTextBoxColumn2.HeaderText = "custEmailAddress";
            this.custEmailAddressDataGridViewTextBoxColumn2.Name = "custEmailAddressDataGridViewTextBoxColumn2";
            // 
            // custIDNumberDataGridViewTextBoxColumn2
            // 
            this.custIDNumberDataGridViewTextBoxColumn2.DataPropertyName = "custIDNumber";
            this.custIDNumberDataGridViewTextBoxColumn2.HeaderText = "custIDNumber";
            this.custIDNumberDataGridViewTextBoxColumn2.Name = "custIDNumberDataGridViewTextBoxColumn2";
            // 
            // custAgeDataGridViewTextBoxColumn2
            // 
            this.custAgeDataGridViewTextBoxColumn2.DataPropertyName = "custAge";
            this.custAgeDataGridViewTextBoxColumn2.HeaderText = "custAge";
            this.custAgeDataGridViewTextBoxColumn2.Name = "custAgeDataGridViewTextBoxColumn2";
            // 
            // custPhoneNumberDataGridViewTextBoxColumn2
            // 
            this.custPhoneNumberDataGridViewTextBoxColumn2.DataPropertyName = "custPhoneNumber";
            this.custPhoneNumberDataGridViewTextBoxColumn2.HeaderText = "custPhoneNumber";
            this.custPhoneNumberDataGridViewTextBoxColumn2.Name = "custPhoneNumberDataGridViewTextBoxColumn2";
            // 
            // custGenderDataGridViewTextBoxColumn2
            // 
            this.custGenderDataGridViewTextBoxColumn2.DataPropertyName = "custGender";
            this.custGenderDataGridViewTextBoxColumn2.HeaderText = "custGender";
            this.custGenderDataGridViewTextBoxColumn2.Name = "custGenderDataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "MedicalAidName";
            this.dataGridViewTextBoxColumn13.HeaderText = "MedicalAidName";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // medicalAidNumberDataGridViewTextBoxColumn2
            // 
            this.medicalAidNumberDataGridViewTextBoxColumn2.DataPropertyName = "medicalAidNumber";
            this.medicalAidNumberDataGridViewTextBoxColumn2.HeaderText = "medicalAidNumber";
            this.medicalAidNumberDataGridViewTextBoxColumn2.Name = "medicalAidNumberDataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Status";
            this.dataGridViewTextBoxColumn14.HeaderText = "Status";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1370, 605);
            this.Controls.Add(this.Name);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.AidNumber);
            this.Controls.Add(this.Gend);
            this.Controls.Add(this.Identity);
            this.Controls.Add(this.Number);
            this.Controls.Add(this.AidName);
            this.Controls.Add(this.Phone);
            this.Controls.Add(this.customerID);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Surname);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            //this.Name = "Customer";
            this.Text = "Customer";
            this.Load += new System.EventHandler(this.Customer_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.varsityPharmacyDataSet2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox Surname;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox customerID;
        private System.Windows.Forms.MaskedTextBox Phone;
        private System.Windows.Forms.ComboBox AidName;
        private System.Windows.Forms.MaskedTextBox Number;
        private System.Windows.Forms.MaskedTextBox Identity;
        private System.Windows.Forms.TextBox Gend;
        private System.Windows.Forms.TextBox AidNumber;
        
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.DataGridViewTextBoxColumn custIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custFNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custLNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custEmailAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custIDNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custAgeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custPhoneNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custGenderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn MedicalAidName;
        private System.Windows.Forms.DataGridViewTextBoxColumn medicalAidNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custID;
        private System.Windows.Forms.DataGridViewTextBoxColumn custFName;
        private System.Windows.Forms.DataGridViewTextBoxColumn custLName;
        private System.Windows.Forms.DataGridViewTextBoxColumn custEmailAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn custIDNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn custAge;
        private System.Windows.Forms.DataGridViewTextBoxColumn custPhoneNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn custGender;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn medicalAidNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Search;
       
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private new System.Windows.Forms.TextBox Name;
        
       // private System.Windows.Forms.BindingSource customersBindingSource;
        private VarsityPharmacyDataSet2 varsityPharmacyDataSet2;
        private System.Windows.Forms.BindingSource bindingSource1;
        private VarsityPharmacyDataSet2TableAdapters.CustomersTableAdapter customersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn custFNameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn custLNameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn custEmailAddressDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn custIDNumberDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn custAgeDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn custPhoneNumberDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn custGenderDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn medicalAidNumberDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
    }
}